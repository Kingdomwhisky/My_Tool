/******************************************************************************
 Copyright (c) 2007 MStar Semiconductor, Inc.
 All rights reserved.

 [Module Name]: Main.c
 [Date]:        23-Oct-2007
 [Comment]:
   Main subroutines.
 [Reversion History]:
*******************************************************************************/

////////////////////////////////
// Main program
////////////////////////////////
void main(void)
{

}
